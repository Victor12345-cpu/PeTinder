# PetConecta / PeTinder — Flutter

## Executar
1. Abra a pasta `petinder_flutter` no VS Code.
2. Execute `flutter pub get`.
3. Execute `flutter run`.

Se a pasta `android/` ainda não existir, execute `flutter create . --project-name petinder --org br.com.petinder` dentro da pasta do projeto.

## Funcionalidades do protótipo
- Descoberta, curtidas/matches e catálogo de adoção.
- Perfil do pet e carteira de saúde local.
- Catálogo de PetSitters com filtros por passeio, hospedagem, creche e visita domiciliar.
- Solicitação de agendamento, simulação de aceite, conclusão e avaliação.
- Agenda/histórico de serviços e chat local demonstrativo.
- Mural comunitário de animais perdidos e encontrados.

## Limitações importantes
Os dados de cuidadores e os preços são exemplos fictícios para demonstração acadêmica. Agendamentos, mensagens e alertas são armazenados localmente no aparelho. O pagamento é apenas uma simulação: não há cobrança. Rastreamento GPS em tempo real, envio de fotos durante passeio, notificações push, autenticação/verificação de identidade, backend compartilhado e integração real com mapas/pagamentos exigem serviços externos, credenciais e configuração adicional.
