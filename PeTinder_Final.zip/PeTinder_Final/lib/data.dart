
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Shelter {
  final String name;
  final String address;
  final String hours;
  final String phone;
  final double lat;
  final double lng;
  final double km;

  const Shelter({
    required this.name,
    required this.address,
    required this.hours,
    required this.phone,
    required this.lat,
    required this.lng,
    required this.km,
  });
}

const Map<String, Shelter> shelters = {
  's1': Shelter(
    name: 'Abrigo Patinhas do Piauí',
    address: 'Centro, Teresina - PI',
    hours: 'Segunda a sábado, 8h às 17h',
    phone: '5586999990001',
    lat: -5.0892,
    lng: -42.8019,
    km: 2.3,
  ),
  's2': Shelter(
    name: 'ONG Amigo Bicho',
    address: 'Zona Leste, Teresina - PI',
    hours: 'Segunda a sexta, 8h às 17h',
    phone: '5586999990002',
    lat: -5.0780,
    lng: -42.7650,
    km: 4.1,
  ),
  's3': Shelter(
    name: 'Protetora Helena Dias',
    address: 'Zona Sul, Teresina - PI',
    hours: 'Todos os dias, 9h às 16h',
    phone: '5586999990003',
    lat: -5.1150,
    lng: -42.8100,
    km: 8.6,
  ),
};

class Animal {
  final String id;
  final String name;
  final String species;
  final String sex;
  final int ageMonths;
  final String size;
  final String breed;
  final String shelterId;
  final bool processing;
  final String photo;

  const Animal({
    required this.id,
    required this.name,
    required this.species,
    required this.sex,
    required this.ageMonths,
    required this.size,
    required this.breed,
    required this.shelterId,
    required this.photo,
    this.processing = false,
  });

  Shelter get shelter => shelters[shelterId]!;

  String get kmText => '${shelter.km.toStringAsFixed(1)} km';

  String get age {
    if (ageMonths < 12) {
      return '$ageMonths meses';
    }

    final years = ageMonths ~/ 12;
    final months = ageMonths % 12;

    if (months == 0) {
      return years == 1 ? '1 ano' : '$years anos';
    }

    return '$years anos e $months meses';
  }

  String get emoji => species == 'Gato' ? '🐱' : '🐶';

  String get tel => shelter.phone;

  String get wa {
    final message = Uri.encodeComponent(
      'Olá! Tenho interesse em adotar $name, que vi no PeTinder.',
    );

    return 'https://wa.me/${shelter.phone}?text=$message';
  }

  String get route =>
      'https://www.google.com/maps/dir/?api=1&destination=${shelter.lat},${shelter.lng}';
}

const List<Animal> animals = [
  Animal(
    id: 'a1',
    name: 'Bolinha',
    species: 'Cachorro',
    sex: 'Macho',
    ageMonths: 8,
    size: 'Pequeno',
    breed: 'Sem raça definida',
    shelterId: 's1',
    photo: 'assets/images/bolinha.jpg',
  ),
  Animal(
    id: 'a2',
    name: 'Mel',
    species: 'Gato',
    sex: 'Fêmea',
    ageMonths: 14,
    size: 'Pequeno',
    breed: 'Sem raça definida',
    shelterId: 's1',
    photo: 'assets/images/mel.jpg',
  ),
  Animal(
    id: 'a3',
    name: 'Thor',
    species: 'Cachorro',
    sex: 'Macho',
    ageMonths: 36,
    size: 'Pequeno',
    breed: 'Bulldog Francês',
    shelterId: 's2',
    processing: true,
    photo: 'assets/images/thor.jpg',
  ),
  Animal(
    id: 'a4',
    name: 'Pipoca',
    species: 'Cachorro',
    sex: 'Fêmea',
    ageMonths: 60,
    size: 'Grande',
    breed: 'Golden Retriever',
    shelterId: 's2',
    photo: 'assets/images/pipoca.jpg',
  ),
  Animal(
    id: 'a5',
    name: 'Luna',
    species: 'Gato',
    sex: 'Fêmea',
    ageMonths: 96,
    size: 'Pequeno',
    breed: 'Siamês',
    shelterId: 's3',
    photo: 'assets/images/luna.jpg',
  ),
  Animal(
    id: 'a6',
    name: 'Rex',
    species: 'Cachorro',
    sex: 'Macho',
    ageMonths: 24,
    size: 'Médio',
    breed: 'Sem raça definida',
    shelterId: 's3',
    photo: 'assets/images/rex.jpg',
  ),
];

class AppState extends ChangeNotifier {
  SharedPreferences? _prefs;

  final Set<String> liked = {};
  final Set<String> passed = {};

  final Map<String, String> health = {};

  final Map<String, String> filters = {
    'species': 'all',
    'sex': 'all',
    'size': 'all',
    'age': 'all',
  };

  bool neutered = false;
  double maxKm = 15;

  bool get initialized => _prefs != null;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();

    liked
      ..clear()
      ..addAll(_prefs!.getStringList('liked') ?? []);

    passed
      ..clear()
      ..addAll(_prefs!.getStringList('passed') ?? []);

    neutered = _prefs!.getBool('neutered') ?? false;
    maxKm = _prefs!.getDouble('maxKm') ?? 15;

    for (final key in filters.keys.toList()) {
      filters[key] = _prefs!.getString('filter_$key') ?? 'all';
    }

    health.clear();

    for (final key in ['rabies', 'dewormer']) {
      final date = _prefs!.getString('health_$key');

      if (date != null) {
        health[key] = date;
      }
    }

    notifyListeners();
  }

  Future<void> _save() async {
    if (_prefs != null) {
      await _prefs!.setStringList('liked', liked.toList());
      await _prefs!.setStringList('passed', passed.toList());
      await _prefs!.setBool('neutered', neutered);
      await _prefs!.setDouble('maxKm', maxKm);

      for (final entry in filters.entries) {
        await _prefs!.setString(
          'filter_${entry.key}',
          entry.value,
        );
      }

      for (final entry in health.entries) {
        await _prefs!.setString(
          'health_${entry.key}',
          entry.value,
        );
      }
    }

    notifyListeners();
  }

  void like(String id) {
    passed.remove(id);
    liked.add(id);
    _save();
  }

  void pass(String id) {
    liked.remove(id);
    passed.add(id);
    _save();
  }

  void resetPassed() {
    passed.clear();
    _save();
  }

  void resetAll() {
    liked.clear();
    passed.clear();
    _save();
  }

  void setFilter(String key, String value) {
    if (!filters.containsKey(key)) return;

    filters[key] = value;
    _save();
  }

  void setKm(double value) {
    maxKm = value;
    _save();
  }

  void setHealth(String key, String date) {
    health[key] = date;
    _save();
  }

  void setNeutered(bool value) {
    neutered = value;
    _save();
  }

  bool _matchesAge(Animal animal) {
    switch (filters['age']) {
      case 'puppy':
        return animal.ageMonths < 12;
      case 'adult':
        return animal.ageMonths >= 12 &&
            animal.ageMonths < 84;
      case 'senior':
        return animal.ageMonths >= 84;
      default:
        return true;
    }
  }

  List<Animal> get deck {
    final result = animals.where((animal) {
      return !liked.contains(animal.id) &&
          !passed.contains(animal.id) &&
          animal.shelter.km <= maxKm;
    }).toList();

    result.sort(
      (a, b) => a.shelter.km.compareTo(b.shelter.km),
    );

    return result;
  }

  List<Animal> get matches {
    return animals
        .where((animal) => liked.contains(animal.id))
        .toList();
  }

  List<Animal> get filtered {
    final result = animals.where((animal) {
      final species = filters['species']!;
      final sex = filters['sex']!;
      final size = filters['size']!;

      final speciesMatches =
          species == 'all' || animal.species == species;

      final sexMatches =
          sex == 'all' || animal.sex == sex;

      final sizeMatches =
          size == 'all' || animal.size == size;

      return speciesMatches &&
          sexMatches &&
          sizeMatches &&
          _matchesAge(animal) &&
          animal.shelter.km <= maxKm;
    }).toList();

    result.sort(
      (a, b) => a.shelter.km.compareTo(b.shelter.km),
    );

    return result;
  }
}

final AppState app = AppState();
