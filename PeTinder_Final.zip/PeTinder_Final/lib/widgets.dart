

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'data.dart';

const brand = Color(0xFFFF3B6B);
const stage = Color(0xFFF6F8FB);
const bold = TextStyle(fontWeight: FontWeight.w800);

Future<void> open(String url) async {
  final uri = Uri.parse(url);

  try {
    await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );
  } catch (e) {
    debugPrint('Não foi possível abrir o endereço: $e');
  }
}

class AnimalPhoto extends StatelessWidget {
  final Animal a;
  final double? h;
  final double? w;

  const AnimalPhoto(
    this.a, {
    super.key,
    this.h,
    this.w,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: h,
      width: w ?? double.infinity,
      color: const Color(0xFFF1F5F9),
      child: Image.asset(
        a.photo,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return Center(
            child: Text(
              a.emoji,
              style: const TextStyle(fontSize: 100),
            ),
          );
        },
      ),
    );
  }
}

class Tag extends StatelessWidget {
  final String t;
  final bool ok;

  const Tag(
    this.t, {
    super.key,
    this.ok = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: ok
            ? const Color(0xFFECFDF5)
            : const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        t,
        style: TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
          color: ok
              ? const Color(0xFF047857)
              : const Color(0xFF0F172A),
        ),
      ),
    );
  }
}

class AnimalTags extends StatelessWidget {
  final Animal a;

  const AnimalTags(this.a, {super.key});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        Tag('Porte ${a.size}'),
        Tag(a.sex),
        Tag(a.age),
        if (a.processing) const Tag('Em processo'),
      ],
    );
  }
}

class ContactBar extends StatelessWidget {
  final Animal a;

  const ContactBar(this.a, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => open('tel:${a.tel}'),
            icon: const Icon(Icons.phone, size: 18),
            label: const Text('Ligar'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => open(a.wa),
            icon: const Icon(Icons.chat, size: 18),
            label: const Text('WhatsApp'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: FilledButton.icon(
            onPressed: () => open(a.route),
            icon: const Icon(Icons.navigation, size: 18),
            label: const Text('Rota'),
          ),
        ),
      ],
    );
  }
}

Widget _row(String label, String value) {
  return Padding(
    padding: const EdgeInsets.only(top: 6),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: const TextStyle(color: Colors.black54),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );
}

void showAnimalSheet(BuildContext context, Animal a) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: Colors.white,
    builder: (context) {
      return DraggableScrollableSheet(
        expand: false,
        initialChildSize: .9,
        maxChildSize: .95,
        builder: (context, controller) {
          return Column(
            children: [
              Expanded(
                child: ListView(
                  controller: controller,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                  ),
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: AnimalPhoto(a, h: 200),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      a.name,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text('${a.species} • ${a.breed}'),
                    if (a.processing)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: Text(
                          'Em processo de adoção. '
                          'Fale com o abrigo para saber se ainda há chance.',
                          style: TextStyle(
                            color: Color(0xFFB45309),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    const SizedBox(height: 12),
                    AnimalTags(a),
                    _row('Sexo', a.sex),
                    _row('Idade aproximada', a.age),
                    _row('Porte', a.size),
                    _row('Abrigo', a.shelter.name),
                    _row('Endereço', a.shelter.address),
                    _row('Horário', a.shelter.hours),
                    _row('Distância', a.kmText),
                    const SizedBox(height: 16),
                    const Text('Sobre o animal', style: bold),
                    const SizedBox(height: 6),
                    Text(
                      '${a.name} está disponível para adoção '
                      'responsável. Entre em contato com o abrigo '
                      'para conhecer melhor o animal e obter '
                      'informações sobre o processo.',
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Exigências para adoção',
                      style: bold,
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      '✓ Apresentar documento de identificação',
                    ),
                    const Text(
                      '✓ Comprovar condições adequadas de cuidado',
                    ),
                    const Text(
                      '✓ Assumir responsabilidade pelo animal',
                    ),
                    const Text(
                      '✓ Conversar com o abrigo antes da adoção',
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                    18,
                    8,
                    18,
                    12,
                  ),
                  child: ContactBar(a),
                ),
              ),
            ],
          );
        },
      );
    },
  );
}
