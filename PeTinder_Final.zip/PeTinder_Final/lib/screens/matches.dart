import 'package:flutter/material.dart';
import '../data.dart';
import '../widgets.dart';

class MatchesScreen extends StatelessWidget {
  const MatchesScreen({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final list = app.matches;
          if (list.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text('Você ainda não tem matches.\nDeslize para a direita em Descobrir para começar.', textAlign: TextAlign.center),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: list.length,
            itemBuilder: (_, i) {
              final a = list[i];
              return Card(
                color: Colors.white,
                child: ListTile(
                  onTap: () => showAnimalSheet(context, a),
                  leading: ClipRRect(borderRadius: BorderRadius.circular(14), child: AnimalPhoto(a, h: 56, w: 56)),
                  title: Text(a.name, style: bold),
                  subtitle: Text('${a.shelter.name} • ${a.kmText} km\n${a.processing ? 'Em processo de adoção' : 'Disponível'}'),
                  isThreeLine: true,
                  trailing: IconButton(tooltip: 'WhatsApp do abrigo', icon: const Icon(Icons.chat, color: brand), onPressed: () => open(a.wa)),
                ),
              );
            },
          );
        },
      );
}
