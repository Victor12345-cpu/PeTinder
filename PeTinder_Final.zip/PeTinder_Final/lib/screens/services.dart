import 'package:flutter/material.dart';
import '../services_data.dart';
import '../widgets.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});
  @override State<ServicesScreen> createState()=>_ServicesScreenState();
}
class _ServicesScreenState extends State<ServicesScreen> {
  String filter='Todos';
  final kinds=['Todos','Passeio','Hospedagem','Creche','Visita domiciliar'];
  @override Widget build(BuildContext context)=>DefaultTabController(length:2,child:Column(children:[
    const TabBar(tabs:[Tab(icon:Icon(Icons.pets),text:'PetSitters'),Tab(icon:Icon(Icons.campaign),text:'Comunidade')],labelColor:brand),
    Expanded(child:TabBarView(children:[
      Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(12,10,12,4),child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:[for(final k in kinds) Padding(padding:const EdgeInsets.only(right:6),child:ChoiceChip(label:Text(k),selected:filter==k,onSelected:(_)=>setState(()=>filter=k)))]))),
        Expanded(child:ListView(padding:const EdgeInsets.all(12),children:[
          const Padding(padding:EdgeInsets.all(4),child:Text('Encontre cuidado de confiança para seu pet.',style:TextStyle(fontWeight:FontWeight.w700))),
          for(final s in petSitters.where((s)=>filter=='Todos'||s.services.contains(filter))) Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(children:[CircleAvatar(radius:28,backgroundColor:stage,child:Text(s.emoji,style:const TextStyle(fontSize:28))),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(s.name,style:bold),Text('${s.city} • ⭐ ${s.rating} (${s.reviews} avaliações)')]))]),
            const SizedBox(height:8),Text(s.bio),const SizedBox(height:8),Wrap(spacing:6,children:[for(final x in s.services) Tag(x,ok:true)]),
            const SizedBox(height:8),...s.prices.entries.map((e)=>Text('${e.key}: R\$ ${e.value.toStringAsFixed(2).replaceAll('.',',')}')),
            Align(alignment:Alignment.centerRight,child:FilledButton.icon(onPressed:()=>_book(context,s),icon:const Icon(Icons.calendar_month),label:const Text('Solicitar serviço')))
          ])))
        ]))
      ]),
      const CommunityScreen()
    ]))
  ]));
  Future<void> _book(BuildContext context,PetSitter s) async {
    String service=s.services.first, pet='Pipoca', payment='Pix';
    DateTime date=DateTime.now().add(const Duration(days:1));
    TimeOfDay time=const TimeOfDay(hour:9,minute:0);
    final pets=['Pipoca','Meu pet'];
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(
      title:Text('Agendar com ${s.name}'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<String>(value:service,decoration:const InputDecoration(labelText:'Serviço'),items:s.services.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>set(()=>service=v!)),
        DropdownButtonFormField<String>(value:pet,decoration:const InputDecoration(labelText:'Pet'),items:pets.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>set(()=>pet=v!)),
        ListTile(contentPadding:EdgeInsets.zero,title:const Text('Data'),subtitle:Text('${date.day.toString().padLeft(2,'0')}/${date.month.toString().padLeft(2,'0')}/${date.year}'),trailing:const Icon(Icons.date_range),onTap:()async{final d=await showDatePicker(context:ctx,initialDate:date,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)));if(d!=null)set(()=>date=d);}),
        ListTile(contentPadding:EdgeInsets.zero,title:const Text('Horário'),subtitle:Text(time.format(ctx)),trailing:const Icon(Icons.schedule),onTap:()async{final t=await showTimePicker(context:ctx,initialTime:time);if(t!=null)set(()=>time=t);}),
        DropdownButtonFormField<String>(value:payment,decoration:const InputDecoration(labelText:'Forma de pagamento (demonstração)'),items:['Pix','Cartão de crédito'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>set(()=>payment=v!)),
        const Text('O pagamento é apenas demonstrativo; nenhuma cobrança será realizada.')
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Enviar solicitação'))]
    )));
    if(ok==true){
      final d='${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
      await servicesState.addBooking(PetServiceBooking(id:DateTime.now().microsecondsSinceEpoch.toString(),sitterId:s.id,sitterName:s.name,service:service,petName:pet,date:d,time:time.format(context),status:'Solicitado',payment:payment,price:s.prices[service]!));
      if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Solicitação registrada! Veja em Agenda.')));
    }
  }
}

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key});
  @override Widget build(BuildContext context)=>ListenableBuilder(listenable:servicesState,builder:(context,_)=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:FilledButton.icon(onPressed:()=>_newReport(context),icon:const Icon(Icons.add),label:const Text('Publicar animal perdido/encontrado'))),
    Expanded(child:servicesState.reports.isEmpty?const Center(child:Text('Nenhum alerta publicado ainda.')):ListView.builder(itemCount:servicesState.reports.length,itemBuilder:(context,i){final r=servicesState.reports[i];return Card(color:Colors.white,margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),child:ListTile(leading:CircleAvatar(child:Icon(r.type=='Perdido'?Icons.search:Icons.pets)),title:Text('${r.type}: ${r.name}',style:bold),subtitle:Text('${r.location}\n${r.description}\n${r.date} • Contato: ${r.contact}'),isThreeLine:true));}))
  ]));
  Future<void> _newReport(BuildContext context) async {
    final name=TextEditingController(),desc=TextEditingController(),loc=TextEditingController(),contact=TextEditingController();
    String type='Perdido';
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Novo alerta'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      DropdownButtonFormField(value:type,items:['Perdido','Encontrado'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>set(()=>type=v!)),
      TextField(controller:name,decoration:const InputDecoration(labelText:'Nome ou identificação do animal')),
      TextField(controller:desc,decoration:const InputDecoration(labelText:'Descrição')),
      TextField(controller:loc,decoration:const InputDecoration(labelText:'Último local visto')),
      TextField(controller:contact,decoration:const InputDecoration(labelText:'Telefone de contato'),keyboardType:TextInputType.phone),
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Publicar'))])));
    if(ok==true&&name.text.trim().isNotEmpty&&loc.text.trim().isNotEmpty){
      await servicesState.addReport(LostPetReport(id:DateTime.now().microsecondsSinceEpoch.toString(),type:type,name:name.text,description:desc.text,location:loc.text,contact:contact.text,date:DateTime.now().toString().substring(0,16)));
    }
  }
}
