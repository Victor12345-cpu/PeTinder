
import 'package:flutter/material.dart';
import '../data.dart';
import '../widgets.dart';

void _like(BuildContext context, Animal a) {
  app.like(a.id);

  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text('Deu match com ${a.name}! Veja em Matches.'),
      ),
    );
}

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final deck = app.deck;

        if (deck.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('🐾', style: TextStyle(fontSize: 56)),
                const SizedBox(height: 12),
                const Text(
                  'Você viu todos os animais!',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: app.resetPassed,
                  child: const Text('Rever animais que passei'),
                ),
              ],
            ),
          );
        }

        final a = deck.first;

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Expanded(
                child: Dismissible(
                  key: ValueKey(a.id),
                  direction: DismissDirection.horizontal,
                  onDismissed: (direction) {
                    if (direction == DismissDirection.startToEnd) {
                      _like(context, a);
                    } else {
                      app.pass(a.id);
                    }
                  },
                  child: _Card(a),
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Deslize para a direita para adotar ou para a esquerda para passar',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.black54,
                ),
              ),

              const SizedBox(height: 8),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      IconButton.filledTonal(
                        iconSize: 30,
                        onPressed: () => app.pass(a.id),
                        icon: const Icon(Icons.close),
                      ),
                      const Text('Passar'),
                    ],
                  ),

                  const SizedBox(width: 40),

                  Column(
                    children: [
                      IconButton.filled(
                        iconSize: 30,
                        style: IconButton.styleFrom(
                          backgroundColor: brand,
                        ),
                        onPressed: () => _like(context, a),
                        icon: const Icon(Icons.favorite),
                      ),
                      const Text('Adotar'),
                    ],
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Card extends StatelessWidget {
  final Animal a;

  const _Card(this.a);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      clipBehavior: Clip.antiAlias,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      child: InkWell(
        onTap: () => showAnimalSheet(context, a),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: AnimalPhoto(a),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${a.name}, ${a.age}',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),

                  Text('${a.species} • ${a.breed} • ${a.sex}'),

                  const SizedBox(height: 8),

                  AnimalTags(a),

                  const SizedBox(height: 8),

                  Row(
                    children: [
                      const Icon(
                        Icons.place,
                        size: 16,
                        color: brand,
                      ),

                      const SizedBox(width: 4),

                      Expanded(
                        child: Text(
                          '${a.shelter.name} • ${a.kmText} km',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


