
import 'package:flutter/material.dart';

import '../data.dart';
import '../widgets.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const Map<String, String> items = {
    'rabies': 'Vacina Antirrábica',
    'dewormer': 'Vermífugo',
  };

  static String formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year}';
  }

  ({Color color, String text}) status(String? iso) {
    if (iso == null || iso.isEmpty) {
      return (
        color: Colors.grey,
        text: 'Data não informada',
      );
    }

    final date = DateTime.tryParse(iso);

    if (date == null) {
      return (
        color: Colors.grey,
        text: 'Data inválida',
      );
    }

    final now = DateTime.now();

    final days = date
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;

    if (days < 0) {
      return (
        color: Colors.red,
        text: 'Vencida em ${formatDate(date)}',
      );
    }

    if (days <= 30) {
      return (
        color: Colors.orange,
        text: 'Vence em $days ${days == 1 ? 'dia' : 'dias'}',
      );
    }

    return (
      color: Colors.green,
      text: 'Em dia • Venc. '
          '${date.month.toString().padLeft(2, '0')}/${date.year}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final pet = animals[3];

    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'Perfil do Pet',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
              ),
            ),

            const Text('Dados e Carteira de Saúde Digital.'),

            const SizedBox(height: 12),

            // Cartão de perfil do animal
            Card(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Foto local do animal
                    Container(
                      width: 112,
                      height: 112,
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: brand,
                        shape: BoxShape.circle,
                      ),
                      child: ClipOval(
                        child: AnimalPhoto(
                          pet,
                          h: 104,
                          w: 104,
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Text(
                      pet.name,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),

                    Text(
                      '${pet.species} • ${pet.age} • '
                      'Porte ${pet.size} • ${pet.breed}',
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 8),

                    const Wrap(
                      spacing: 6,
                      children: [
                        Tag('Sem restrições'),
                        Tag('Sociável', ok: true),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Carteira de Saúde Digital
            Card(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  children: [
                    const ListTile(
                      leading: Icon(
                        Icons.shield,
                        color: brand,
                      ),
                      title: Text(
                        'Carteira de Saúde Digital',
                        style: bold,
                      ),
                    ),

                    for (final item in items.entries)
                      Builder(
                        builder: (context) {
                          final result = status(
                            app.health[item.key],
                          );

                          return ListTile(
                            leading: const Icon(Icons.vaccines),
                            title: Text(
                              item.value,
                              style: bold,
                            ),
                            subtitle: Text(
                              result.text,
                              style: TextStyle(
                                color: result.color,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            trailing: Icon(
                              Icons.circle,
                              color: result.color,
                              size: 14,
                            ),
                            onTap: () async {
                              final now = DateTime.now();

                              final selected = await showDatePicker(
                                context: context,
                                initialDate: now,
                                firstDate: DateTime(now.year - 1),
                                lastDate: DateTime(now.year + 5),
                                helpText: 'Válida até',
                              );

                              if (selected != null) {
                                app.setHealth(
                                  item.key,
                                  selected
                                      .toIso8601String()
                                      .substring(0, 10),
                                );
                              }
                            },
                          );
                        },
                      ),

                    // Controle de castração
                    SwitchListTile(
                      title: const Text(
                        'Castração realizada',
                        style: bold,
                      ),
                      value: app.neutered,
                      onChanged: app.setNeutered,
                    ),

                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                      child: Text(
                        'Toque em um item para editar a validade. '
                        'O status é calculado automaticamente.',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
