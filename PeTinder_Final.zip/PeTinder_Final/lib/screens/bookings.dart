import 'package:flutter/material.dart';
import '../services_data.dart';
import '../widgets.dart';

class BookingsScreen extends StatelessWidget {
 const BookingsScreen({super.key});
 @override Widget build(BuildContext context)=>ListenableBuilder(listenable:servicesState,builder:(context,_)=>servicesState.bookings.isEmpty
 ? const Center(child:Text('Você ainda não possui serviços agendados.'))
 : ListView(padding:const EdgeInsets.all(12),children:[
   const Text('Meus serviços',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
   for(final b in servicesState.bookings) Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
     Row(children:[const Icon(Icons.pets,color:brand),const SizedBox(width:8),Expanded(child:Text(b.service,style:bold)),Tag(b.status,ok:b.status=='Aceito')]),
     Text('Cuidador: ${b.sitterName}'),Text('Pet: ${b.petName}'),Text('Data: ${b.date} às ${b.time}'),
     Text('Valor: R\$ ${b.price.toStringAsFixed(2).replaceAll('.',',')} • ${b.payment}'),
     const SizedBox(height:8),Wrap(spacing:8,children:[
       if(b.status=='Solicitado') OutlinedButton(onPressed:()=>servicesState.updateBooking(b.copyWith(status:'Aceito')),child:const Text('Simular aceite')),
       if(b.status!='Concluído') OutlinedButton(onPressed:()=>servicesState.updateBooking(b.copyWith(status:'Concluído')),child:const Text('Finalizar serviço')),
       if(b.status=='Concluído') TextButton(onPressed:()=>_review(context,b),child:const Text('Avaliar cuidador')),
       TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatScreen(booking:b))),child:const Text('Abrir chat'))
     ])
   ])))
 ]));
 Future<void> _review(BuildContext context,PetServiceBooking b) async {
   double rating=5;
   await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:Text('Avaliar ${b.sitterName}'),content:Column(mainAxisSize:MainAxisSize.min,children:[const Text('Como foi o serviço?'),Slider(value:rating,min:1,max:5,divisions:4,label:rating.toStringAsFixed(0),onChanged:(v)=>set(()=>rating=v)),Text('${rating.toStringAsFixed(0)} estrelas')]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:(){servicesState.rate(b.id,rating);Navigator.pop(ctx);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Avaliação registrada neste protótipo.')));},child:const Text('Enviar'))])));
 }
}

class ChatScreen extends StatefulWidget {
 final PetServiceBooking booking;
 const ChatScreen({super.key,required this.booking});
 @override State<ChatScreen> createState()=>_ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen>{
 final c=TextEditingController();
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('Chat • ${widget.booking.sitterName}')),body:Column(children:[
   Expanded(child:ListenableBuilder(listenable:servicesState,builder:(context,_) {final msgs=servicesState.messages[widget.booking.id]??[];return ListView(padding:const EdgeInsets.all(12),children:[const Text('Conversa demonstrativa entre tutor e PetSitter.',textAlign:TextAlign.center),for(final m in msgs)Align(alignment:Alignment.centerRight,child:Card(child:Padding(padding:const EdgeInsets.all(10),child:Text(m))))]);})),
   SafeArea(child:Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:c,decoration:const InputDecoration(hintText:'Digite uma mensagem',border:OutlineInputBorder()))),IconButton(onPressed:(){if(c.text.trim().isNotEmpty){servicesState.addMessage(widget.booking.id,c.text.trim());c.clear();}},icon:const Icon(Icons.send,color:brand))])))
 ]));
}
