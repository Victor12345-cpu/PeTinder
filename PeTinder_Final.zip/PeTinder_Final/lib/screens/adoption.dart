
import 'package:flutter/material.dart';

import '../data.dart';
import '../widgets.dart';

class AdoptionScreen extends StatelessWidget {
  const AdoptionScreen({super.key});

  Widget _group(
    String label,
    String key,
    Map<String, String> options,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: bold),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: options.entries.map((entry) {
              return ChoiceChip(
                label: Text(entry.value),
                selected: app.filters[key] == entry.key,
                onSelected: (selected) {
                  app.setFilter(key, entry.key);
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final list = app.filtered;

        return Column(
          children: [
            Container(
              color: Colors.white,
              child: ExpansionTile(
                title: const Text('Filtros', style: bold),
                subtitle: Text(
                  '${list.length} ${list.length == 1 ? 'animal' : 'animais'} • mais próximos primeiro',
                ),
                childrenPadding: const EdgeInsets.fromLTRB(
                  16,
                  0,
                  16,
                  8,
                ),
                expandedCrossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  _group(
                    'Espécie',
                    'species',
                    {
                      'all': 'Todos',
                      'Cachorro': '🐶 Cães',
                      'Gato': '🐱 Gatos',
                    },
                  ),
                  _group(
                    'Sexo',
                    'sex',
                    {
                      'all': 'Qualquer',
                      'Macho': 'Macho',
                      'Fêmea': 'Fêmea',
                    },
                  ),
                  _group(
                    'Porte',
                    'size',
                    {
                      'all': 'Qualquer',
                      'Pequeno': 'Pequeno',
                      'Médio': 'Médio',
                      'Grande': 'Grande',
                    },
                  ),
                  _group(
                    'Idade',
                    'age',
                    {
                      'all': 'Qualquer',
                      'puppy': 'Filhote',
                      'adult': 'Adulto',
                      'senior': 'Idoso',
                    },
                  ),
                  Text(
                    'Distância máxima: ${app.maxKm.round()} km',
                    style: bold,
                  ),
                  Slider(
                    value: app.maxKm,
                    min: 2,
                    max: 15,
                    divisions: 13,
                    onChanged: app.setKm,
                  ),
                ],
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Nenhum animal combina com os filtros.\n'
                          'Tente ampliar a distância.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: list.length,
                      itemBuilder: (context, index) {
                        return _AnimalCard(list[index]);
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
}

class _AnimalCard extends StatelessWidget {
  final Animal animal;

  const _AnimalCard(this.animal);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.only(bottom: 14),
      child: InkWell(
        onTap: () => showAnimalSheet(context, animal),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                AnimalPhoto(animal, h: 170),
                Positioned(
                  top: 10,
                  left: 10,
                  child: Tag(
                    animal.processing
                        ? 'Em processo de adoção'
                        : 'Disponível',
                    ok: !animal.processing,
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: Tag(animal.kmText),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        animal.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text('${animal.sex} • ${animal.age}'),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${animal.species} • ${animal.breed}',
                  ),
                  const SizedBox(height: 8),
                  AnimalTags(animal),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(
                        Icons.place,
                        size: 16,
                        color: brand,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          animal.shelter.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
