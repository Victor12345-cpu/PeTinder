import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PetSitter {
  final String id, name, bio, city;
  final double rating;
  final int reviews;
  final List<String> services;
  final Map<String, double> prices;
  final String emoji;
  const PetSitter({required this.id, required this.name, required this.bio, required this.city,
    required this.rating, required this.reviews, required this.services, required this.prices, required this.emoji});
}

const petSitters = <PetSitter>[
  PetSitter(id:'ps1', name:'Ana Souza', bio:'Cuidadora experiente, passeios individuais e muito carinho.', city:'Teresina - PI', rating:4.9, reviews:38, services:['Passeio','Visita domiciliar','Hospedagem'], prices:{'Passeio':35,'Visita domiciliar':45,'Hospedagem':100}, emoji:'👩🏻'),
  PetSitter(id:'ps2', name:'Lucas Martins', bio:'Dog walker. Atendo cães de pequeno, médio e grande porte.', city:'Teresina - PI', rating:4.8, reviews:24, services:['Passeio','Creche'], prices:{'Passeio':30,'Creche':70}, emoji:'🧑🏽'),
  PetSitter(id:'ps3', name:'Mariana Lima', bio:'Hospedagem familiar e visitas para gatos e cães.', city:'Teresina - PI', rating:5.0, reviews:16, services:['Hospedagem','Creche','Visita domiciliar'], prices:{'Hospedagem':120,'Creche':80,'Visita domiciliar':50}, emoji:'👩🏽'),
];

class PetServiceBooking {
  final String id, sitterId, sitterName, service, petName, date, time, status, payment;
  final double price;
  const PetServiceBooking({required this.id, required this.sitterId, required this.sitterName,
    required this.service, required this.petName, required this.date, required this.time,
    required this.status, required this.payment, required this.price});
  PetServiceBooking copyWith({String? status, String? payment}) => PetServiceBooking(
    id:id, sitterId:sitterId, sitterName:sitterName, service:service, petName:petName,
    date:date, time:time, status:status??this.status, payment:payment??this.payment, price:price);
  Map<String,dynamic> toJson()=>{'id':id,'sitterId':sitterId,'sitterName':sitterName,'service':service,'petName':petName,'date':date,'time':time,'status':status,'payment':payment,'price':price};
  factory PetServiceBooking.fromJson(Map<String,dynamic> j)=>PetServiceBooking(
    id:j['id'],sitterId:j['sitterId'],sitterName:j['sitterName'],service:j['service'],petName:j['petName'],
    date:j['date'],time:j['time'],status:j['status'],payment:j['payment'],price:(j['price'] as num).toDouble());
}

class LostPetReport {
  final String id, type, name, description, location, contact, date;
  const LostPetReport({required this.id,required this.type,required this.name,required this.description,required this.location,required this.contact,required this.date});
  Map<String,dynamic> toJson()=>{'id':id,'type':type,'name':name,'description':description,'location':location,'contact':contact,'date':date};
  factory LostPetReport.fromJson(Map<String,dynamic> j)=>LostPetReport(id:j['id'],type:j['type'],name:j['name'],description:j['description'],location:j['location'],contact:j['contact'],date:j['date']);
}

class ServicesState extends ChangeNotifier {
  List<PetServiceBooking> bookings=[];
  List<LostPetReport> reports=[];
  final Map<String,List<String>> messages={};
  final Map<String,double> ratings={};
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    bookings=(p.getStringList('pc_bookings')??[]).map((s)=>PetServiceBooking.fromJson(Map<String,dynamic>.from(_decode(s)))).toList();
    reports=(p.getStringList('pc_reports')??[]).map((s)=>LostPetReport.fromJson(Map<String,dynamic>.from(_decode(s)))).toList();
  }
  dynamic _decode(String s) { // JSON is kept in preferences for this local prototype.
    return jsonDecode(s);
  }
  Future<void> _save() async {
    final p=await SharedPreferences.getInstance();
    await p.setStringList('pc_bookings',bookings.map((b)=>_jsonEncode(b.toJson())).toList());
    await p.setStringList('pc_reports',reports.map((r)=>_jsonEncode(r.toJson())).toList());
    notifyListeners();
  }
  Future<void> addBooking(PetServiceBooking b) async { bookings=[b,...bookings]; await _save(); }
  Future<void> updateBooking(PetServiceBooking b) async { bookings=bookings.map((x)=>x.id==b.id?b:x).toList(); await _save(); }
  Future<void> addReport(LostPetReport r) async { reports=[r,...reports]; await _save(); }
  void addMessage(String id,String message) { messages.putIfAbsent(id,()=>[]).add(message); notifyListeners(); }
  void rate(String id,double value) { ratings[id]=value; notifyListeners(); }
}
String _jsonEncode(Object o) => jsonEncode(o);
// Implemented through dart:convert.

final servicesState = ServicesState();
