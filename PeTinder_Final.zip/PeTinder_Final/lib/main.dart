
import 'package:flutter/material.dart';

import 'data.dart';
import 'screens/discover.dart';
import 'screens/adoption.dart';
import 'screens/services.dart';
import 'screens/bookings.dart';
import 'screens/profile.dart';
import 'screens/matches.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await app.load();

  runApp(const PetConectaApp());
}

class PetConectaApp extends StatelessWidget {
  const PetConectaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PeTinder',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF3B6B),
        ),
        scaffoldBackgroundColor: const Color(0xFFFFF8FA),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final List<Widget> _screens = const [
    DiscoverScreen(),
    AdoptionScreen(),
    ServicesScreen(),
    BookingsScreen(),
    ProfileScreen(),
  ];

  final List<String> _titles = [
    'Descobrir',
    'Adoção',
    'Serviços Pet',
    'Agendamentos',
    'Perfil',
  ];

  void _openMatches() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const MatchesScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _titles[_index],
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'Meus matches',
            onPressed: _openMatches,
            icon: const Icon(
              Icons.favorite,
              color: Color(0xFFFF3B6B),
            ),
          ),
        ],
      ),
      body: IndexedStack(
        index: _index,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) {
          setState(() {
            _index = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.pets_outlined),
            selectedIcon: Icon(Icons.pets),
            label: 'Descobrir',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border),
            selectedIcon: Icon(Icons.favorite),
            label: 'Adoção',
          ),
          NavigationDestination(
            icon: Icon(Icons.storefront_outlined),
            selectedIcon: Icon(Icons.storefront),
            label: 'Serviços',
          ),
          NavigationDestination(
            icon: Icon(Icons.calendar_month_outlined),
            selectedIcon: Icon(Icons.calendar_month),
            label: 'Agenda',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}
