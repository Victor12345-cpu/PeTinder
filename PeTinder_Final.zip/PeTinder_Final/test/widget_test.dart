import 'package:flutter_test/flutter_test.dart';
import 'package:petinder_flutter/main.dart';

void main() {
  testWidgets('Aplicativo PeTinder inicia', (WidgetTester tester) async {
    await tester.pumpWidget(const PetConectaApp());

    expect(find.text('Descobrir'), findsOneWidget);
  });
}